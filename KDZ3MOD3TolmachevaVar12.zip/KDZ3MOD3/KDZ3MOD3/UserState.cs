﻿
namespace KDZ3MOD3
{
    public enum UserState
    {
        Introduction,
        Menu,
        SortingMenu,
        ChoosingSelectionField,
        ChoosingSortingOrder,
        SavingMenu,
        Selecting,
        InputtingSelectionValue,
        ChoosingSavingMethod,
        Saving
    }
}
